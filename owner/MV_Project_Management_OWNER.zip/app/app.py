# © 2026 Martín Viera. Todos los derechos reservados.
"""MV Project Management — dashboard operativo (Streamlit).

Un único motor (mvpm/) alimenta este dashboard, la API REST (api/main.py) y
los exportadores — sin lógica de negocio duplicada entre capas. Los datos
viven en una base SQLite real (mvpm/db.py) en el equipo del cliente, detrás
de un login con usuario y contraseña (mvpm/auth.py).
"""

import pathlib
import re
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
import streamlit as st

from mvpm import (
    BRAND,
    advisor,
    ai,
    auth,
    capacitacion,
    case_study,
    catalog,
    conectores,
    data_engineering as dataeng,
    db,
    demo_pharma,
    demo_real,
    dependencies as dep_mod,
    exporters,
    glossary,
    governance,
    health,
    help_center,
    i18n,
    importer,
    invitado,
    licensing,
    modelos,
    organigrama,
    owner,
    plantillas,
    pmbok,
    policies,
    prioritizer,
    reports,
    reviews,
    seguro,
    tutorial,
)
from mvpm import copilot as copilot_mod

#: El logo MV. Vive dentro de `mvpm/` porque el spec de PyInstaller copia ese
#: directorio entero (`datas`), así que viaja en el .exe sin sumar una regla de
#: empaquetado nueva. Se resuelve desde el paquete y no desde este archivo:
#: congelado, app.py y mvpm/ no quedan uno al lado del otro.
LOGO = pathlib.Path(copilot_mod.__file__).resolve().parent / "data" / "logo-mv.png"

st.set_page_config(
    page_title="MV Project Management",
    # Si el archivo faltara —una copia incompleta—, Streamlit levanta igual con
    # el icono por defecto en vez de morir en la primera línea de la app.
    page_icon=str(LOGO) if LOGO.exists() else ":material/checklist:",
    layout="wide",
    # Sin esto el menú "···" ofrece Record a screencast, Report a bug y About
    # Streamlit: tres cosas que le cuentan al cliente con qué está hecho el
    # producto que compró, y ninguna que le sirva.
    menu_items={"Get help": None, "Report a Bug": None, "About": None},
)

st.markdown(
    f"""
    <style>
    /* El programa se instala con su icono, su acceso directo y su ventana
       propia (mvpm/ventana.py). Lo que quedaba delatando que abajo hay
       Streamlit es su barra de herramientas: el botón Deploy, el menú
       hamburguesa, la franja de color de arriba y el "Made with Streamlit" del
       pie. Nada de eso significa algo para quien usa el programa —el Deploy
       incluso invita a publicar el portafolio del cliente en la nube de
       Streamlit— así que se oculta.

       Se ocultan los elementos puntuales y NO el header entero a propósito: la
       flecha para plegar y desplegar la barra lateral vive ahí, y esconder el
       header completo deja al usuario sin forma de recuperarla si la cierra. */
    [data-testid="stToolbar"] {{ visibility: hidden; height: 0; position: fixed; }}
    [data-testid="stDecoration"] {{ display: none; }}
    [data-testid="stStatusWidget"] {{ display: none; }}
    [data-testid="stAppDeployButton"] {{ display: none; }}
    #MainMenu {{ visibility: hidden; }}
    footer {{ visibility: hidden; height: 0; }}
    [data-testid="stHeader"] {{ background: transparent; }}

    .stApp {{ background-color: {BRAND['navy']}; }}
    [data-testid="stMetricValue"] {{ color: {BRAND['amber']}; }}
    h1, h2, h3 {{ color: {BRAND['ink']}; }}
    </style>
    """,
    unsafe_allow_html=True,
)

db.init_db()


def T(key: str) -> str:
    return i18n.t(key, LANG_ES_DEFAULT)


LANG_ES_DEFAULT = "es"  # se reasigna abajo una vez que hay sesión iniciada, T() ya está definida


# ------------------------------------------------------------- autenticación

if "user" not in st.session_state:
    st.session_state["user"] = None

# Modo invitado: se puede usar el producto sin crear cuenta. Los datos viven en
# la sesión (mvpm/invitado.py), no en la base — ver ese módulo para el porqué.
INVITADO = st.session_state.get("invitado", False)


def _entrar_como_invitado(almacen) -> None:
    st.session_state["invitado"] = True
    st.session_state["invitado_almacen"] = almacen
    st.session_state["user"] = {"nombre": "Invitado", "rol": "invitado", "id": None}
    st.rerun()


if st.session_state["user"] is None:
    st.title("MV Project Management")

    # Primero lo que no pide nada a cambio: probar el producto. La cuenta se
    # ofrece abajo, para quien ya decidió que quiere guardar su trabajo.
    st.markdown("#### Probalo ahora, sin crear cuenta")
    _c1, _c2 = st.columns(2)
    if _c1.button("Subir mi Excel de proyectos", type="primary", icon=":material/upload_file:",
                  use_container_width=True):
        _entrar_como_invitado(invitado.almacen_vacio())
    if _c2.button("Probar con datos reales del gobierno británico (132 proyectos)",
                   icon=":material/public:",
                  use_container_width=True):
        _entrar_como_invitado(invitado.con_portafolio_real())
    st.caption("Sin registro y sin tarjeta. En modo invitado los datos quedan en "
               "esta sesión del navegador y no se guardan — cuando quieras "
               "conservarlos, creás la cuenta y los volvés a subir.")
    st.divider()

    if db.contar_usuarios() == 0:
        st.subheader("Creá la cuenta de administrador")
        st.caption("Sos la primera persona en usar este servidor — tu cuenta va a ser admin. El resto del equipo se registra después con su propio usuario y contraseña.")
        with st.form("bootstrap_admin"):
            nombre = st.text_input("Nombre")
            email = st.text_input("Email")
            password = st.text_input("Contraseña (mín. 8 caracteres)", type="password")
            enviado = st.form_submit_button("Crear cuenta de administrador")
            if enviado:
                try:
                    user = auth.registrar(email, nombre, password)
                    st.session_state["user"] = user
                    st.rerun()
                except ValueError as e:
                    st.error(str(e))
    else:
        tab_login, tab_registro = st.tabs(["Ingresar", "Crear cuenta"])
        with tab_login:
            with st.form("login"):
                email = st.text_input("Email", key="login_email")
                password = st.text_input("Contraseña", type="password", key="login_password")
                enviado = st.form_submit_button("Ingresar")
                if enviado:
                    user = auth.iniciar_sesion(email, password)
                    if user:
                        st.session_state["user"] = user
                        st.rerun()
                    else:
                        st.error("Email o contraseña incorrectos.")
        with tab_registro:
            with st.form("registro"):
                nombre = st.text_input("Nombre", key="reg_nombre")
                email = st.text_input("Email", key="reg_email")
                password = st.text_input("Contraseña (mín. 8 caracteres)", type="password", key="reg_password")
                enviado = st.form_submit_button("Crear cuenta")
                if enviado:
                    try:
                        user = auth.registrar(email, nombre, password)
                        st.session_state["user"] = user
                        st.rerun()
                    except ValueError as e:
                        st.error(str(e))
    st.stop()

user = st.session_state["user"]

LANG = st.sidebar.selectbox("Idioma / Language / Idioma", ["es", "en", "pt"], index=0)
LANG_ES_DEFAULT = LANG  # T() ya definida arriba usa esta variable global

LICENSE_TOKEN = st.sidebar.text_input(
    "Token de licencia", type="password",
    help="Se emite automáticamente al pagar el plan Professional. Se pega una "
         "sola vez: queda guardado en esta computadora. Sin token, corrés la "
         "prueba completa de 7 días con todo desbloqueado.",
) or None

# El dueño no tiene que pegar ningún token en su propia herramienta: si esta
# máquina tiene su clave privada, el marcador se firma solo en el arranque.
# En la máquina de un cliente esto no hace nada —no hay clave que firmar— así
# que no afloja el candado: ver mvpm/owner.py.
owner.activar_automatico()

# Y si escribe su email ahí arriba, se intenta lo mismo explícitamente. El
# email NO es la credencial: sin la clave en la máquina no desbloquea nada,
# justamente para que un cliente no entre gratis escribiendo el mail del dueño,
# que está publicado en la landing.
if LICENSE_TOKEN and owner.es_email_owner(LICENSE_TOKEN):
    if owner.activar_automatico() or owner.es_owner():
        LICENSE_TOKEN = None
    else:
        st.sidebar.error(
            "Esta máquina no tiene tu clave de licencias, así que no puedo "
            "firmar el modo dueño. Corré una vez MV_ProjectManagement_OWNER.bat "
            "y pegá tu clave privada: después no se pide nunca más."
        )
        LICENSE_TOKEN = None

# La licencia se pega UNA vez. Antes vivía sólo acá, en la sesión de Streamlit:
# había que volver a buscarla en el mail en cada apertura, y la API de BI —otro
# proceso, el que consumen Power BI y Tableau— no la veía nunca, así que a los
# 7 días le devolvía 402 a un cliente con licencia paga vigente.
if LICENSE_TOKEN:
    if licensing.verify_license(LICENSE_TOKEN):
        licensing.guardar_token(LICENSE_TOKEN)
    # Un token inválido no borra el que ya estaba guardado: el error más
    # probable es un copiado a medias, y en ese caso perder la licencia buena
    # sería peor que ignorar la mala.
else:
    LICENSE_TOKEN = licensing.token_guardado()

st.sidebar.divider()
st.sidebar.caption(f"{user['nombre']} · {user['rol']}")
if st.sidebar.button("Cerrar sesión"):
    st.session_state["user"] = None
    st.rerun()

# Candado de la prueba de 7 días. El programa se descarga completo y funciona
# 100% durante una semana; al vencer se bloquea hasta cargar una licencia paga
# vigente. Bloquear NO borra datos: al pagar, se sigue con todo lo cargado.
#
# Edición Owner: la instalación del dueño del producto corre sin candado. La
# decisión vive en mvpm/owner.py y no acá, porque antes dependía de una env var
# que sólo seteaba el launcher del .exe: el mismo dueño abriendo su programa con
# ./run.sh app o con el .bat portable caía igual en "la prueba venció". Nada de
# esto viaja en lo que recibe un cliente (tests/test_owner.py lo fija) ni toca
# licensing.py — ver owner/panel.py para emitir licencias reales de venta.
_es_owner = owner.es_owner()
_acceso = (
    owner.estado_acceso()
    if _es_owner else
    # El invitado no pasa por el candado: todavía no es cliente, está viendo si
    # el producto le sirve. Cobrarle una prueba a alguien que ni siquiera dejó
    # un email es el orden inverso.
    {"acceso": True, "modo": "invitado", "plan": None, "dias_restantes": None,
     "mensaje": "Modo invitado — los datos no se guardan."}
    if INVITADO else licensing.estado_acceso(LICENSE_TOKEN)
)
if _acceso["modo"] == "owner":
    st.sidebar.success(_acceso["mensaje"], icon=":material/verified:")
elif _acceso["modo"] == "invitado":
    st.sidebar.info("Modo invitado — nada se guarda", icon=":material/person:")
elif _acceso["modo"] == "trial":
    st.sidebar.info(f"Prueba: quedan {_acceso['dias_restantes']} día(s)",
                    icon=":material/hourglass_top:")
elif _acceso["modo"] == "licencia":
    st.sidebar.success(_acceso["mensaje"], icon=":material/schedule:")

if not _acceso["acceso"]:
    st.title("La prueba de 7 días venció")
    st.warning(_acceso["mensaje"])
    st.markdown(
        "**Tus datos siguen guardados.** Nada se borró: apenas cargues una "
        "licencia Professional válida, seguís exactamente donde estabas, con "
        "todos los proyectos, tareas, definiciones y responsables que cargaste."
    )
    st.markdown(
        "1. Comprá el plan **Professional (US$9/usuario/mes)** desde la web.\n"
        "2. Al aprobarse el pago recibís un **token de licencia**.\n"
        "3. Pegalo en **«Token de licencia»** en la barra lateral y listo."
    )
    st.caption("¿Ya pagaste y no te llegó el token? Escribinos a vieraschiavi@gmail.com.")
    st.stop()

# Empresa activa — alcance de todo lo versionado (definiciones, organigrama,
# responsables, notas PMBOK). Cada empresa guarda su propia historia.
#
# El invitado no crea ni elige empresa: crear una escribiría en la base
# compartida a nombre de alguien que no tiene cuenta. Las secciones que usan
# EMPRESA_ID quedan fuera de su menú, así que no hace falta un id real.
if INVITADO:
    EMPRESA_ID = None
else:
    db.obtener_o_crear_empresa("Mi empresa")
    _empresas = db.listar_empresas()
    _empresa_nombres = _empresas["nombre"].tolist()
    with st.sidebar.expander("Empresa", icon=":material/business:"):
        empresa_sel = st.selectbox("Empresa activa", _empresa_nombres,
                                   index=0, key="empresa_sel")
        _nueva = st.text_input("Nueva empresa", key="empresa_nueva")
        if st.button("Crear empresa", key="crear_empresa_btn") and _nueva.strip():
            db.crear_empresa(_nueva.strip())
            st.rerun()
    EMPRESA_ID = int(_empresas[_empresas["nombre"] == empresa_sel]["id"].iloc[0])

# Modelo de IA elegido por esta empresa. Se aplica en CADA corrida del script y
# no una sola vez: Streamlit vuelve a ejecutar todo el archivo en cada
# interacción, y la elección vive en un contextvar por hilo de sesión (ver
# mvpm/modelos.py). Reponerla acá arriba garantiza que cualquier llamada a la IA
# más abajo use el modelo de la empresa activa, incluso si el usuario acaba de
# cambiar de empresa en el selector.
if not INVITADO:
    _cfg_ia = db.obtener_version_actual(EMPRESA_ID, "config_ia", "modelos")
    modelos.aplicar_seleccion(_cfg_ia["contenido"] if _cfg_ia else None)

st.sidebar.title(T("app_title"))

if INVITADO:
    # Se ofrece sólo lo que funciona sin cuenta: subir el archivo y analizar el
    # portafolio. Lo que queda afuera (gobernanza, organigrama, plantillas,
    # PMBOK) no se esconde por capricho: guarda versiones por empresa en la
    # base, y sin cuenta no hay empresa a la cual atribuirlas.
    nav_options = [
        T("nav_import"), T("nav_portfolio"), T("nav_health"),
        T("nav_dependencies"), T("nav_backlog"), T("nav_tasks"),
        T("nav_copilot"), T("nav_reports"), T("nav_glossary"),
        T("nav_policies"), T("nav_tutorial"),
    ]
else:
    nav_options = [
        T("nav_tutorial"), T("nav_case_study"), T("nav_real_demo"), T("nav_pharma"),
        T("nav_portfolio"), T("nav_tasks"), T("nav_health"), T("nav_dependencies"),
        T("nav_backlog"), T("nav_copilot"), T("nav_advisor"), T("nav_reports"),
        T("nav_governance"), T("nav_organigrama"), T("nav_pmbok"), T("nav_plantillas"),
        T("nav_reviews"), T("nav_glossary"), T("nav_policies"),
        T("nav_import"), T("nav_conectores"), T("nav_data_eng"), T("nav_capacitacion"),
        T("nav_config_ia"),
    ]
    if user["rol"] == "admin":
        nav_options.append(T("nav_users"))

# Un invitado que entró con el botón de "subir mi Excel" cae directo en
# Importar: es el único paso que tiene sentido con el portafolio vacío.
_indice_inicial = 0
if INVITADO and st.session_state["invitado_almacen"].vacio:
    _indice_inicial = nav_options.index(T("nav_import"))

section = st.sidebar.radio("Sección", nav_options, index=_indice_inicial)

st.title(T("app_title"))


def load_data():
    # El invitado lee de su almacén de sesión; el usuario registrado, de la base.
    # Ambos devuelven las mismas columnas, así que de acá para abajo el
    # dashboard no distingue entre uno y otro.
    if INVITADO:
        a = st.session_state["invitado_almacen"]
        return a.proyectos(), a.tareas(), a.equipo()
    return db.projects(), db.tasks(), db.team()


proj_df, task_df, team_df = load_data()
equipo_df = (pd.DataFrame(columns=["id", "nombre", "email", "rol"])
             if INVITADO else db.listar_usuarios())


# Escritura: el invitado escribe en su almacén de sesión y el usuario
# registrado en la base. Se despacha acá una sola vez para que los formularios
# de más abajo no tengan que preguntar quién es en cada uno.
def _crear_proyecto(**campos):
    if INVITADO:
        return st.session_state["invitado_almacen"].crear_proyecto(**campos)
    return db.crear_proyecto(**campos)


def _crear_tarea(**campos):
    if INVITADO:
        return st.session_state["invitado_almacen"].crear_tarea(**campos)
    return db.crear_tarea(**campos)


def _solo_con_cuenta(accion: str) -> bool:
    """True (y avisa) si la acción pide cuenta y estamos en modo invitado.

    Editar y archivar necesitan un registro estable al cual volver; el almacén
    de invitado se borra al cerrar la pestaña, así que ofrecerlo sería prometer
    algo que no se cumple. Importar y crear sí funcionan.
    """
    if not INVITADO:
        return False
    st.info(f"{accion} necesita una cuenta. En modo invitado podés importar tu "
            f"Excel, crear proyectos y analizar todo el portafolio — lo que no "
            f"se puede es guardar cambios de forma permanente.")
    return True


_GRADIENTE_ROJO = (215, 48, 39)
_GRADIENTE_AMARILLO = (255, 255, 191)
_GRADIENTE_VERDE = (26, 152, 80)


def _interpolar_color(c1, c2, t):
    return tuple(round(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))


def _color_por_indice(valor):
    """Rojo→amarillo→verde sobre 0-100, sin matplotlib (Styler.background_gradient
    lo requiere y no está en requirements.txt — esto evita sumar esa dependencia
    sólo para un gradiente de color)."""
    if pd.isna(valor):
        return ""
    v = max(0.0, min(100.0, float(valor)))
    if v <= 50:
        r, g, b = _interpolar_color(_GRADIENTE_ROJO, _GRADIENTE_AMARILLO, v / 50)
    else:
        r, g, b = _interpolar_color(_GRADIENTE_AMARILLO, _GRADIENTE_VERDE, (v - 50) / 50)
    brillo = (r * 299 + g * 587 + b * 114) / 1000
    texto = "#000" if brillo > 140 else "#fff"
    return f"background-color: rgb({r},{g},{b}); color: {texto}"


def _selector_usuario(label: str, key: str, actual_id=None):
    opciones = ["(sin asignar)"] + equipo_df["nombre"].tolist()
    idx = 0
    if actual_id is not None and not equipo_df.empty:
        match = equipo_df[equipo_df["id"] == actual_id]
        if not match.empty:
            idx = opciones.index(match.iloc[0]["nombre"])
    elegido = st.selectbox(label, opciones, index=idx, key=key)
    if elegido == "(sin asignar)":
        return None
    return int(equipo_df[equipo_df["nombre"] == elegido]["id"].iloc[0])


if proj_df.empty and task_df.empty:
    # El invitado y el usuario registrado tienen estados vacíos DISTINTOS. Antes
    # compartían este bloque y el invitado terminaba llamando a
    # db.cargar_datos_de_ejemplo(): eso sembraba 20 proyectos en la base
    # compartida del servidor (rompiendo el "nada se guarda" que promete la
    # barra lateral, y ensuciando el portafolio de los usuarios reales) mientras
    # el invitado —que lee de su almacén de sesión— no veía aparecer nada.
    if INVITADO:
        st.info("Todavía no cargaste proyectos en esta sesión.")
        if st.button("Cargar el portafolio real del gobierno británico (132 proyectos)",
                     icon=":material/public:"):
            st.session_state["invitado_almacen"] = invitado.con_portafolio_real()
            st.rerun()
    else:
        st.info("Todavía no cargaste proyectos en este servidor.")
        if st.button("Cargar datos de ejemplo para explorar", icon=":material/potted_plant:"):
            db.cargar_datos_de_ejemplo()
            st.rerun()

# ------------------------------------------------------------------ secciones

if section == T("nav_tutorial"):
    st.subheader(T("nav_tutorial"))
    st.caption("Guía operativa de cada herramienta del programa — cómo usarla, no solo qué es.")
    for i, s in enumerate(tutorial.sections()):
        with st.expander(f"{s['titulo']}", expanded=(i == 0)):
            st.write(s["resumen"])
            st.markdown("**Cómo usarlo:**")
            for paso in s["pasos"]:
                st.markdown(f"- {paso}")
            if s["tips"]:
                st.markdown("**Tips:**")
                for tip in s["tips"]:
                    st.markdown(tip)

elif section == T("nav_case_study"):
    st.subheader(T("nav_case_study"))
    st.caption("Un proyecto simulado completo, recorrido por las herramientas del programa paso a "
               "paso — con los números reales que calcula el motor sobre el dato de ejemplo, no un "
               "guion inventado para la demo.")
    caso = case_study.narrar_caso()
    st.markdown(f"**Proyecto elegido:** {caso['nombre']} ({caso['proyecto_id']}) — "
                f"índice de salud {caso['indice']}/100, estado *{caso['estado']}*.")
    st.divider()
    for paso in caso["pasos"]:
        st.markdown(f"##### {paso['titulo']}")
        st.caption(paso["seccion"])
        st.write(paso["texto"])
        st.write("")
    if proj_df.empty:
        st.info("Todavía no cargaste tus propios proyectos — este recorrido usa el dato de ejemplo "
                "para que veas el flujo completo antes de cargar los tuyos.")

elif section == T("nav_real_demo"):
    st.subheader(T("nav_real_demo"))
    st.caption(f"Fuente: {demo_real.FUENTE}")
    st.caption(f"No son datos sintéticos — son 132 proyectos reales de gobierno, filtrados a los "
               f"que tienen calificación de confianza y presupuesto numérico completos en el "
               f"informe original. [Descargar el dataset original]({demo_real.FUENTE_URL}).")

    resumen = demo_real.resumen_portafolio()
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Proyectos reales analizados", resumen["total_proyectos"])
    c2.metric("Sobre presupuesto (año fiscal)", resumen["sobre_presupuesto"])
    c3.metric("Presupuesto total", f"£{resumen['presupuesto_total_m']:,.0f}M")
    c4.metric("Ejecutado total", f"£{resumen['ejecutado_total_m']:,.0f}M")
    st.caption("'Sobre presupuesto' compara el baseline y el ejecutado del año fiscal 2021/22 "
               "reportado por cada departamento — no el costo total a lo largo de vida del proyecto.")

    st.info(
        f"**Ahorro estimado de tiempo**: revisar a mano estos {resumen['total_proyectos']} "
        f"proyectos para encontrar cuáles están sobre presupuesto — a un supuesto de "
        f"{resumen['minutos_por_revision_manual_supuesto']} minutos por proyecto, un número "
        f"explícito, no medido — tomaría ~{resumen['horas_ahorradas_estimadas']} horas de trabajo "
        f"manual de un PMO. El motor los detecta a todos en segundos, cada vez que se le pide."
    )

    st.subheader("Los 10 más desviados, detectados por el motor")
    st.dataframe(resumen["proyectos_sobre_presupuesto_detalle"], use_container_width=True)

    st.divider()
    st.subheader("Dos casos, con el texto real del informe anual")
    for nombre in ["Social Housing Decarbonisation Fund", "Borders & Trade Programme"]:
        c = demo_real.caso(nombre)
        icon = {"Red": "🔴", "Amber": "🟡", "Green": "🟢"}[c["rag"]]
        with st.expander(f"{icon} {c['nombre']} — {c['depto']}"):
            st.write(c["resumen"])
            st.markdown(f"**Lo que calcula el motor sobre este proyecto:** presupuesto £{c['presupuesto_m']:.1f}M, "
                        f"ejecutado £{c['ejecutado_m']:.1f}M ({c['ejecucion_pct']}%) — "
                        + ("marcado sobre presupuesto." if c["sobre_presupuesto"] else "dentro de presupuesto."))
            st.markdown("**Texto real del informe anual sobre el presupuesto:**")
            st.caption(c["narrativa_real"])
            st.markdown("**Texto real del informe anual sobre la revisión de entrega:**")
            st.caption(c["revision_real"])

elif section == T("nav_pharma"):
    st.subheader(T("nav_pharma"))
    st.caption(f"Fuente: {demo_pharma.FUENTE} — [ClinicalTrials.gov]({demo_pharma.FUENTE_URL}). "
               "Un ensayo clínico es un proyecto: tiene sponsor (un laboratorio multinacional), "
               "fechas, fase y un estado que se comporta igual que el estado de un proyecto.")
    st.caption("ClinicalTrials.gov no publica presupuesto, así que la señal de PM acá es el "
               "estado del ensayo (no la plata) — no se inventan cifras de presupuesto.")

    r = demo_pharma.resumen_portafolio()
    c1, c2, c3 = st.columns(3)
    c1.metric("Ensayos reales analizados", r["total_ensayos"])
    c2.metric("En riesgo (terminados/suspendidos)", r["en_riesgo"])
    c3.metric("Laboratorios", len(r["por_sponsor"]))
    st.info(
        f"**Ahorro estimado**: revisar a mano estos {r['total_ensayos']} ensayos para marcar "
        f"cuáles están frenados — a un supuesto explícito de {r['minutos_por_revision_manual_supuesto']} "
        f"minutos por ensayo — serían ~{r['horas_ahorradas_estimadas']} horas de trabajo manual. "
        "El motor los clasifica a todos en segundos."
    )

    cc1, cc2 = st.columns(2)
    with cc1:
        st.markdown("**Por estado (dato real del ensayo)**")
        _est = pd.DataFrame({"estado": list(r["por_estado"].keys()),
                             "ensayos": list(r["por_estado"].values())})
        st.bar_chart(_est, x="estado", y="ensayos")
    with cc2:
        st.markdown("**Por laboratorio**")
        _lab = pd.DataFrame({"laboratorio": list(r["por_sponsor"].keys()),
                             "ensayos": list(r["por_sponsor"].values())})
        st.bar_chart(_lab, x="laboratorio", y="ensayos")

    st.subheader("Ensayos que el motor marca en riesgo")
    st.dataframe(demo_pharma.en_riesgo_detalle(15), use_container_width=True)

    st.divider()
    st.subheader("De acá a Power BI, end-to-end")
    st.markdown(
        "El mismo motor sirve estos ensayos por la **API REST local** (`./run.sh api`), así que "
        "Power BI se conecta al dato en vivo sin exportar planillas:\n\n"
        "1. Levantá la API: `./run.sh api` (queda en `http://127.0.0.1:8600`).\n"
        "2. Doble clic en `distribucion/powerbi/MV_ProjectManagement_Pharma.pbids` — Power BI "
        "Desktop abre ya conectado a `/api/demo/pharma`.\n"
        "3. Cargá y armá el tablero (ensayos por laboratorio, por estado, semáforo por criticidad).\n\n"
        "Guía completa: `distribucion/powerbi/README.md`."
    )
    st.download_button("Descargar la tabla lista para BI (CSV)",
                       demo_pharma.tabla_para_bi().to_csv(index=False),
                       file_name="ensayos_pharma_bi.csv")

elif section == T("nav_portfolio"):
    kpis = catalog.kpis(proj_df)
    c1, c2, c3, c4, c5, c6 = st.columns(6)
    c1.metric(T("kpi_projects"), kpis["proyectos_activos"])
    c2.metric(T("kpi_health"), f"{health.overall_index(proj_df, task_df, team_df)}/100")
    riesgo = int((health.project_health(proj_df, task_df, team_df)["estado"] == "riesgo").sum())
    c3.metric(T("kpi_at_risk"), riesgo)
    c4.metric(T("kpi_budget"), f"{kpis['ejecucion_pct_promedio']}%")
    bloqueadas = int((task_df["estado"] == "blocked").sum())
    c5.metric(T("kpi_blocked"), bloqueadas)
    a_tiempo = int((health.project_health(proj_df, task_df, team_df)["dim_cronograma"] >= 70).sum())
    c6.metric(T("kpi_on_time"), a_tiempo)

    with st.expander("Nuevo proyecto", icon=":material/add:"):
        with st.form("nuevo_proyecto", clear_on_submit=True):
            nombre = st.text_input("Nombre del proyecto")
            col1, col2 = st.columns(2)
            portafolio = col1.text_input("Portafolio", value="Producto Core")
            sponsor = col2.text_input("Sponsor")
            dueno_id = _selector_usuario("Dueño", "nuevo_proy_dueno")
            segmento = st.selectbox("Segmento", ["Interno", "Cliente externo", "Regulatorio"])
            col3, col4 = st.columns(2)
            fecha_inicio = col3.date_input("Fecha de inicio", value=date.today())
            fecha_fin = col4.date_input("Fecha de fin", value=date.today())
            col5, col6 = st.columns(2)
            presupuesto = col5.number_input("Presupuesto", min_value=0.0, step=100.0)
            ejecutado = col6.number_input("Ejecutado", min_value=0.0, step=100.0)
            criticidad = st.selectbox("Criticidad", ["Alta", "Media", "Baja"], index=1)
            enviado = st.form_submit_button("Crear proyecto")
            if enviado:
                if not nombre.strip():
                    st.error("El nombre es obligatorio.")
                else:
                    _crear_proyecto(
                        nombre=nombre.strip(), portafolio=portafolio.strip() or "Sin portafolio",
                        sponsor=sponsor.strip() or None, dueno_id=dueno_id, segmento=segmento,
                        fecha_inicio=str(fecha_inicio), fecha_fin=str(fecha_fin),
                        presupuesto=presupuesto, ejecutado=ejecutado, criticidad=criticidad,
                    )
                    st.success(f"Proyecto '{nombre}' creado.")
                    st.rerun()

    if not proj_df.empty:
        st.subheader(T("nav_portfolio"))
        st.dataframe(catalog.catalog(proj_df).drop(columns=["_id"]), use_container_width=True)

        # Editar y archivar necesitan un registro estable al cual volver; el
        # almacén del invitado se borra al cerrar la pestaña, así que se le
        # ofrece la cuenta en vez de un botón que promete algo que no cumple.
        if INVITADO:
            _solo_con_cuenta("Editar o archivar un proyecto")
        else:
            with st.expander("Ficha de proyecto (editar / archivar / eliminar)", icon=":material/edit:"):
                opciones = (proj_df["nombre"] + " — " + proj_df["proyecto_id"]).tolist()
                elegido = st.selectbox("Elegí un proyecto", opciones, key="ficha_proyecto_selector")
                fila = proj_df.iloc[opciones.index(elegido)]
                with st.form("editar_proyecto"):
                    nombre_e = st.text_input("Nombre", value=fila["nombre"])
                    col1, col2 = st.columns(2)
                    portafolio_e = col1.text_input("Portafolio", value=fila["portafolio"])
                    sponsor_e = col2.text_input("Sponsor", value=fila["sponsor"] or "")
                    dueno_id_e = _selector_usuario(
                        "Dueño", "editar_proy_dueno",
                        actual_id=equipo_df[equipo_df["nombre"] == fila["dueno"]]["id"].iloc[0]
                        if fila["dueno"] and (equipo_df["nombre"] == fila["dueno"]).any() else None,
                    )
                    segmento_e = st.selectbox("Segmento", ["Interno", "Cliente externo", "Regulatorio"],
                                               index=["Interno", "Cliente externo", "Regulatorio"].index(fila["segmento"])
                                               if fila["segmento"] in ["Interno", "Cliente externo", "Regulatorio"] else 0)
                    col3, col4 = st.columns(2)
                    presupuesto_e = col3.number_input("Presupuesto", min_value=0.0, step=100.0, value=float(fila["presupuesto"]))
                    ejecutado_e = col4.number_input("Ejecutado", min_value=0.0, step=100.0, value=float(fila["ejecutado"]))
                    criticidad_e = st.selectbox("Criticidad", ["Alta", "Media", "Baja"],
                                                 index=["Alta", "Media", "Baja"].index(fila["criticidad"]))
                    guardar = st.form_submit_button("Guardar cambios", icon=":material/save:")
                    if guardar:
                        db.actualizar_proyecto(
                            int(fila["_id"]), nombre=nombre_e.strip(), portafolio=portafolio_e.strip(),
                            sponsor=sponsor_e.strip() or None, dueno_id=dueno_id_e, segmento=segmento_e,
                            presupuesto=presupuesto_e, ejecutado=ejecutado_e, criticidad=criticidad_e,
                        )
                        st.success("Cambios guardados.")
                        st.rerun()
                col_a, col_b = st.columns(2)
                if col_a.button("Archivar proyecto", key="archivar_proy", icon=":material/archive:"):
                    db.archivar_proyecto(int(fila["_id"]))
                    st.success("Proyecto archivado.")
                    st.rerun()
                if col_b.button("Eliminar definitivamente", key="eliminar_proy", icon=":material/delete:"):
                    db.eliminar_proyecto(int(fila["_id"]))
                    st.success("Proyecto eliminado.")
                    st.rerun()

        st.subheader("Por portafolio")
        st.bar_chart(catalog.por_portafolio(proj_df).set_index("portafolio")[["presupuesto", "ejecutado"]])

elif section == T("nav_tasks"):
    st.subheader(T("nav_tasks"))

    with st.expander("Nueva tarea", icon=":material/add:"):
        if proj_df.empty:
            st.warning("Creá un proyecto primero.")
        else:
            with st.form("nueva_tarea", clear_on_submit=True):
                proyecto_opciones = (proj_df["nombre"] + " — " + proj_df["proyecto_id"]).tolist()
                proyecto_elegido = st.selectbox("Proyecto", proyecto_opciones)
                proyecto_real_id = int(proj_df.iloc[proyecto_opciones.index(proyecto_elegido)]["_id"])
                titulo = st.text_input("Título de la tarea")
                responsable_id = _selector_usuario("Responsable", "nueva_tarea_resp")
                col1, col2 = st.columns(2)
                estado = col1.selectbox("Estado", ["todo", "in_progress", "blocked", "done"])
                prioridad = col2.selectbox("Prioridad", ["Alta", "Media", "Baja"], index=1)
                vencimiento = st.date_input("Vencimiento", value=date.today())
                dep_opciones = ["(ninguna)"] + (task_df["titulo"] + " — " + task_df["tarea_id"]).tolist()
                dependencia = st.selectbox("Depende de", dep_opciones)
                enviado = st.form_submit_button("Crear tarea")
                if enviado:
                    if not titulo.strip():
                        st.error("El título es obligatorio.")
                    else:
                        depende_de_id = None
                        if dependencia != "(ninguna)":
                            depende_de_id = int(task_df.iloc[dep_opciones.index(dependencia) - 1]["_id"])
                        _crear_tarea(
                            proyecto_id=proyecto_real_id, titulo=titulo.strip(),
                            responsable_id=responsable_id, estado=estado,
                            vencimiento=str(vencimiento), prioridad=prioridad, depende_de=depende_de_id,
                        )
                        st.success(f"Tarea '{titulo}' creada.")
                        st.rerun()

    if not task_df.empty:
        st.dataframe(task_df.drop(columns=["_id"]), use_container_width=True)

        if INVITADO:
            _solo_con_cuenta("Editar o eliminar una tarea")
        else:
            with st.expander("Ficha de tarea (editar / eliminar)", icon=":material/edit:"):
                t_opciones = (task_df["titulo"] + " — " + task_df["tarea_id"]).tolist()
                t_elegida = st.selectbox("Elegí una tarea", t_opciones, key="ficha_tarea_selector")
                t_fila = task_df.iloc[t_opciones.index(t_elegida)]
                with st.form("editar_tarea"):
                    titulo_e = st.text_input("Título", value=t_fila["titulo"])
                    responsable_actual = equipo_df[equipo_df["nombre"] == t_fila["responsable"]]["id"].iloc[0] \
                        if t_fila["responsable"] and (equipo_df["nombre"] == t_fila["responsable"]).any() else None
                    responsable_id_e = _selector_usuario("Responsable", "editar_tarea_resp", actual_id=responsable_actual)
                    col1, col2 = st.columns(2)
                    estado_e = col1.selectbox("Estado", ["todo", "in_progress", "blocked", "done"],
                                               index=["todo", "in_progress", "blocked", "done"].index(t_fila["estado"]))
                    prioridad_e = col2.selectbox("Prioridad", ["Alta", "Media", "Baja"],
                                                  index=["Alta", "Media", "Baja"].index(t_fila["prioridad"]))
                    guardar_t = st.form_submit_button("Guardar cambios", icon=":material/save:")
                    if guardar_t:
                        db.actualizar_tarea(int(t_fila["_id"]), titulo=titulo_e.strip(),
                                             responsable_id=responsable_id_e, estado=estado_e, prioridad=prioridad_e)
                        st.success("Cambios guardados.")
                        st.rerun()
                if st.button("Eliminar tarea", key="eliminar_tarea", icon=":material/delete:"):
                    db.eliminar_tarea(int(t_fila["_id"]))
                    st.success("Tarea eliminada.")
                    st.rerun()

elif section == T("nav_health"):
    h = health.project_health(proj_df, task_df, team_df)
    st.subheader(f"{T('nav_health')} — índice global: {health.overall_index(proj_df, task_df, team_df)}/100")
    estado_color = {"saludable": "🟢", "observacion": "🟡", "riesgo": "🔴"}
    h_display = h.copy()
    h_display["estado"] = h_display["estado"].map(lambda e: f"{estado_color.get(e,'')} {e}")
    st.dataframe(h_display, use_container_width=True)
    st.subheader("Matriz por dimensión")
    matriz = health.matriz_por_dimension(proj_df, task_df, team_df).set_index("nombre")
    columnas_dim = [c for c in matriz.columns if c.startswith("dim_")]
    st.dataframe(matriz.style.map(_color_por_indice, subset=columnas_dim), use_container_width=True)

elif section == T("nav_dependencies"):
    st.subheader(T("nav_dependencies"))
    bloqueos = dep_mod.bloqueos_activos(task_df)
    if bloqueos.empty:
        st.success("No hay tareas bloqueadas activas.")
    else:
        st.dataframe(bloqueos[["tarea_id", "titulo", "proyecto_id", "tareas_impactadas"]], use_container_width=True)
    st.subheader("Dependencias inconsistentes")
    orphans = dep_mod.orphan_dependencies(task_df)
    if orphans.empty:
        st.success("Sin dependencias huérfanas.")
    else:
        st.warning(f"{len(orphans)} dependencia(s) apuntan a una tarea inexistente.")
        st.dataframe(orphans, use_container_width=True)

elif section == T("nav_backlog"):
    st.subheader(T("nav_backlog"))
    st.caption("Ordenado por valor esperado = criticidad × prioridad × urgencia × impacto en dependencias.")
    st.dataframe(
        prioritizer.prioritized_backlog(proj_df, task_df)[
            ["tarea_id", "titulo", "proyecto_id", "estado", "valor_esperado", "tareas_impactadas", "dias_restantes"]
        ],
        use_container_width=True,
    )

elif section == T("nav_copilot"):
    st.subheader(T("nav_copilot"))
    st.caption("El motor de reglas responde siempre. Si hay ANTHROPIC_API_KEY configurada y todavía hay cupo de IA en tu plan, Claude pule el lenguaje sin inventar cifras nuevas.")
    # El cupo es la mitad del control; la otra es que el plan incluya la IA.
    # Antes sólo se miraba el cupo, así que un plan sin "copiloto_ia" habría
    # tenido IA igual mientras le quedaran consultas — la feature del plan no
    # se consultaba en ningún lado.
    puede_ia, detalle_cupo = (
        (True, "ilimitado (owner)") if _es_owner
        else licensing.puede_usar_ia(LICENSE_TOKEN)
        if licensing.tiene_feature(LICENSE_TOKEN, "copiloto_ia")
        else (False, "tu plan no incluye el copiloto con IA"))
    st.caption(f"Cupo de IA: {detalle_cupo}")
    q = st.text_input("Preguntá sobre el portafolio", "¿Qué está bloqueando los proyectos?")
    if st.button("Preguntar"):
        result = copilot_mod.answer(q, proj_df, task_df, team_df, license_token=LICENSE_TOKEN)
        st.info(result["answer"])
        st.caption("Respuesta enriquecida con IA" if result["ai_enriched"] else "Respuesta del motor de reglas (sin IA)")

elif section == T("nav_advisor"):
    st.subheader(T("nav_advisor"))
    st.caption("El motor de reglas detecta los problemas siempre. La redacción de la sugerencia se "
               "puede pulir con el proveedor de IA que tengas configurado — nunca inventa el problema "
               "ni el número que lo sustenta, sólo redacta mejor la acción sugerida.")
    disponibles = advisor.proveedores_disponibles()
    etiquetas = {"claude": "Claude", "chatgpt": "ChatGPT", "gemini": "Gemini"}
    opciones_ia = ["Motor de reglas (sin IA)"] + [etiquetas[p] for p in disponibles]
    elegido = st.radio("Redacción de la sugerencia", opciones_ia, horizontal=True)
    proveedor = next((p for p in disponibles if etiquetas[p] == elegido), None)
    if not disponibles:
        st.caption("Sin proveedores de IA configurados — corriendo 100% con el motor de reglas. "
                   "Para sumar redacción con IA, configurá ANTHROPIC_API_KEY (Claude), o "
                   "OPENAI_API_KEY + OPENAI_MODEL (ChatGPT), o GEMINI_API_KEY + GEMINI_MODEL (Gemini).")

    problemas = advisor.detectar_problemas(proj_df, task_df, team_df)
    icon_severidad = {"alta": "🔴", "media": "🟡", "baja": "⚪"}
    if not problemas:
        st.success("El motor de reglas no detectó problemas activos en el portafolio ahora mismo.")
    for p in problemas:
        seg = db.obtener_seguimiento_por_problema(p["id"])
        with st.expander(f"{icon_severidad[p['severidad']]} {p['titulo']}"):
            resultado = advisor.sugerir(p, proveedor=proveedor)
            st.write(resultado["sugerencia"])
            st.caption(f"Redactado por {etiquetas[resultado['proveedor']]}" if resultado["ai_enriched"]
                       else "Motor de reglas (sin IA)")
            if seg:
                nuevo_estado = st.selectbox(
                    "Estado del seguimiento", ["abierto", "en_progreso", "resuelto"],
                    index=["abierto", "en_progreso", "resuelto"].index(seg["estado"]),
                    key=f"estado_{p['id']}",
                )
                if nuevo_estado != seg["estado"]:
                    db.actualizar_estado_seguimiento(seg["id"], nuevo_estado)
                    st.rerun()
            elif st.button("Poner en seguimiento", key=f"seguir_{p['id']}", icon=":material/push_pin:"):
                db.crear_o_actualizar_seguimiento(p["id"], p["tipo"], p["titulo"],
                                                   resultado["sugerencia"], resultado["proveedor"])
                st.rerun()

    seguimientos_df = db.listar_seguimientos()
    if not seguimientos_df.empty:
        st.divider()
        st.subheader("Seguimientos")
        st.caption("Se mantienen acá aunque el problema original ya no se detecte — así queda el "
                   "historial de qué se resolvió y cuándo.")
        st.dataframe(seguimientos_df[["titulo", "tipo", "estado", "proveedor", "actualizado_en"]],
                     use_container_width=True)

elif section == T("nav_reports"):
    st.subheader(T("nav_reports"))
    if not (_es_owner or licensing.tiene_feature(LICENSE_TOKEN, "reportes_automaticos")):
        st.warning("Tu plan no incluye los reportes automáticos. El plan "
                   "Professional sí los incluye.", icon=":material/lock:")
        st.stop()
    st.code(reports.as_text(proj_df, task_df, team_df), language=None)
    st.download_button("Descargar JSON del portafolio", exporters.to_json_bundle(proj_df, task_df, team_df), file_name="portafolio_mvpm.json")
    st.download_button("Descargar Excel del portafolio", exporters.to_excel_bytes(proj_df, task_df, team_df), file_name="portafolio_mvpm.xlsx")

elif section == T("nav_reviews"):
    st.subheader(T("nav_reviews"))
    s = reviews.summary()
    if s["es_beta_sin_resenas"]:
        st.info(f"{T('reviews_empty_title')} — {T('reviews_empty_body')}", icon=":material/star:")
    else:
        st.metric("Calificación promedio", f"{s['promedio']} / 5 ({s['total']} reseñas)")
        for r in reviews.list_reviews():
            autor, rol, empresa = (seguro.escapar(r[k]) for k in ("autor", "rol", "empresa"))
            st.markdown(f"**{'⭐' * r['calificacion']}** — *{autor}, {rol} en {empresa}*")
            st.write(seguro.escapar(r["comentario"]))
            st.divider()
    with st.expander("Dejar una reseña"):
        with st.form("nueva_resena"):
            autor = st.text_input("Tu nombre")
            empresa = st.text_input("Empresa")
            rol = st.text_input("Rol")
            calificacion = st.slider("Calificación", 1, 5, 5)
            comentario = st.text_area("Comentario")
            enviado = st.form_submit_button("Enviar reseña")
            if enviado and autor and comentario:
                reviews.add_review(autor, empresa, rol, calificacion, comentario, verificado=False)
                st.success("¡Gracias! Tu reseña queda pendiente de verificación antes de publicarse.")

elif section == T("nav_glossary"):
    st.subheader(T("nav_glossary"))
    st.dataframe(glossary.glossary(), use_container_width=True)

elif section == T("nav_policies"):
    st.subheader(T("nav_policies"))
    pol = policies.evaluate(proj_df, task_df, team_df)
    for _, row in pol.iterrows():
        icon = "✅" if row["estado"] == "cumple" else "⚠️"
        st.markdown(f"{icon} **{row['politica']}** — {row['evidencia']}")
    st.divider()
    st.subheader("Matriz de automatización y adopción")
    for row in help_center.automation_rows():
        nivel_icon = {"auto": "🟢 automático", "parcial": "🟡 parcial", "humano": "🔴 humano"}[row["nivel"]]
        st.markdown(f"**{row['area']}** — {nivel_icon}")
        st.caption(row["detalle"])

elif section == T("nav_pmbok"):
    st.subheader(T("nav_pmbok"))
    st.caption("El PMBOK (guía del PMI) en dos registros: **técnico** (como lo diría un PMP) y "
               "**en criollo** (castellano de todos los días). No es una certificación oficial — "
               "es una referencia honesta de qué cubre el producto y qué no.")
    r = pmbok.resumen()
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Áreas de conocimiento", r["total_areas"])
    c2.metric("Grupos de procesos", r["grupos_proceso"])
    c3.metric("Cobertura completa", r["completa"])
    c4.metric("No cubierta", r["no_cubierta"])

    tab_areas, tab_grupos = st.tabs(["10 áreas de conocimiento", "5 grupos de procesos"])
    icon = {"completa": "✅", "parcial": "🟡", "no_cubierta": "⚪"}
    with tab_areas:
        for a in pmbok.areas():
            with st.expander(f"{icon[a['cobertura']]} {a['area']} ({a['area_en']})"):
                st.markdown("**Técnico (PMBOK):**")
                st.write(a["definicion_tecnica"])
                st.markdown("**En criollo:**")
                st.info(a["criollo"])
                if a["como_lo_cubre"]:
                    st.markdown(f"**Cómo lo cubre este producto:** {a['como_lo_cubre']}")
                if a["lo_que_falta"]:
                    st.caption(f"Lo que falta: {a['lo_que_falta']}")
                _nota = pmbok.nota_empresa(EMPRESA_ID, a["clave"])
                if _nota:
                    st.success(f"Nota de la empresa (validada por "
                               f"{seguro.escapar(_nota['validado_por_nombre'])}, "
                               f"{seguro.escapar(_nota['validado_por_cargo'])}): "
                               f"{seguro.escapar(_nota['texto'])}")
                with st.form(f"nota_pmbok_{a['clave']}"):
                    st.caption("Nota interna de tu empresa (algo que no se automatiza) — se guarda "
                               "versionada para esta empresa.")
                    txt = st.text_area("Nota", value=_nota["texto"] if _nota else "",
                                       key=f"nota_txt_{a['clave']}")
                    cn, cc = st.columns(2)
                    val_n = cn.text_input("Validado por (nombre)", key=f"nota_n_{a['clave']}")
                    val_c = cc.text_input("Cargo", key=f"nota_c_{a['clave']}")
                    if st.form_submit_button("Guardar nota", icon=":material/save:") and txt.strip() and val_n.strip():
                        pmbok.guardar_nota(EMPRESA_ID, a["clave"], txt.strip(), val_n.strip(), val_c.strip())
                        st.success("Nota guardada.")
                        st.rerun()
    with tab_grupos:
        st.caption("El ciclo de vida de la dirección de proyectos, en orden.")
        for g in pmbok.grupos_proceso():
            with st.expander(f"{g['nombre']} ({g['nombre_en']})"):
                st.markdown("**Técnico (PMBOK):**")
                st.write(g["definicion_tecnica"])
                st.markdown("**En criollo:**")
                st.info(g["criollo"])
                _resp = organigrama.responsable_vigente(EMPRESA_ID, g["clave"])
                if _resp:
                    st.success(f"Responsable asignado: {_resp['persona'].get('nombre')} "
                               f"({_resp['persona'].get('cargo') or 's/d'}) — validado por "
                               f"{_resp['validado_por_nombre']}, {_resp['validado_por_cargo']}. "
                               "Se asigna desde la pestaña Organigrama.")

elif section == T("nav_governance"):
    st.subheader(T("nav_governance"))
    st.caption("Cada concepto ya viene con una definición preestablecida (de fábrica). La IA "
               "puede recomendar una versión mejorada, y el **Data Owner / Data Steward** la "
               "valida o la edita y la guarda. Cada cambio queda versionado para esta empresa.")
    _provs = ai.proveedores_disponibles()
    _etq = {"claude": "Claude", "chatgpt": "ChatGPT", "gemini": "Gemini"}
    _opts = ["Motor de reglas (definición de fábrica)"] + [_etq[p] for p in _provs]
    _elegido = st.radio("¿Quién recomienda la definición?", _opts, horizontal=True)
    _prov = next((p for p in _provs if _etq[p] == _elegido), None)
    if not _provs:
        st.caption("Sin proveedores de IA configurados — las recomendaciones salen del motor de "
                   "reglas (la definición de fábrica). Para que la IA pula las definiciones, "
                   "configurá ANTHROPIC_API_KEY (Claude), OPENAI_API_KEY+OPENAI_MODEL (ChatGPT) "
                   "o GEMINI_API_KEY+GEMINI_MODEL (Gemini).")

    for c in governance.catalogo():
        vig = governance.definicion_vigente(EMPRESA_ID, c["clave"])
        estado_icon = "✅" if vig["estado"] == "validado" else "📋"
        with st.expander(f"{estado_icon} {c['termino']}  ·  {c['categoria']}"):
            st.markdown(f"**Definición vigente** ({vig['origen']}):")
            st.write(seguro.escapar(vig["texto"]))
            if vig["validado_por_nombre"]:
                st.caption(f"Validada por {seguro.escapar(vig['validado_por_nombre'])} "
                           f"({seguro.escapar(vig['validado_por_cargo'])}) "
                           f"· recomendada por {vig['recomendado_por']}")
            rec = governance.recomendar_definicion(c["clave"], _prov)
            with st.form(f"gov_{c['clave']}"):
                st.caption(f"Recomendado por {rec['recomendado_por']} — validá, editá y guardá:")
                txt = st.text_area("Definición", value=rec["texto"], key=f"gov_txt_{c['clave']}")
                co, cs = st.columns(2)
                # `validador`, no `owner`: este scope importa el módulo mvpm.owner
                # (edición del dueño del producto) y reusar el nombre lo pisaba.
                validador = co.text_input("Data Owner que valida (nombre)", key=f"gov_o_{c['clave']}")
                cargo = cs.text_input("Cargo", value="Data Owner", key=f"gov_c_{c['clave']}")
                if st.form_submit_button("Validar y guardar", icon=":material/save:") and txt.strip() and validador.strip():
                    governance.guardar(EMPRESA_ID, c["clave"], txt.strip(), rec["recomendado_por"],
                                       validador.strip(), cargo.strip())
                    st.success("Definición validada y guardada (nueva versión).")
                    st.rerun()
            hist = db.historial_versiones(EMPRESA_ID, "concepto", c["clave"])
            if len(hist) > 0:
                st.caption(f"{len(hist)} versión(es) guardada(s) — la historia completa queda.")
                st.dataframe(hist[["contenido", "estado", "validado_por_nombre", "creado_en"]],
                             use_container_width=True)

elif section == T("nav_organigrama"):
    st.subheader(T("nav_organigrama"))
    st.caption("Cargá el organigrama (Excel/CSV o base SQLite) y la IA autocompleta por defecto "
               "quién es responsable de cada etapa del proyecto — según su cargo. Todo editable "
               "y guardado versionado por empresa.")

    _provs = ai.proveedores_disponibles()
    _org_actual = db.listar_organigrama(EMPRESA_ID)

    with st.expander("Cargar / actualizar organigrama", icon=":material/cloud_upload:", expanded=_org_actual.empty):
        st.caption("Reconoce columnas comunes (nombre, cargo, área, reporta a) sin exigir un "
                   "formato exacto.")
        fuente_tipo = st.radio("Origen", ["Excel/CSV", "Base SQLite (.db)"], horizontal=True)
        if fuente_tipo == "Excel/CSV":
            up = st.file_uploader("Subí el organigrama (CSV/Excel)", type=["csv", "xlsx"], key="org_upl")
            if up is not None:
                # dtype=str, igual que en el importador de proyectos: un legajo
                # "00123" leído como número pierde los ceros de adelante y pasa
                # a ser 123 — deja de coincidir con el legajo del ERP y la
                # persona no se puede cruzar contra ningún otro sistema. Lo
                # mismo con cédulas, códigos de centro de costo y teléfonos.
                df_org = (pd.read_csv(up, dtype=str) if up.name.endswith("csv")
                          else pd.read_excel(up, dtype=str))
                personas = organigrama.parsear(df_org)
                st.write(f"{len(personas)} persona(s) detectada(s):")
                st.dataframe(pd.DataFrame(personas), use_container_width=True)
                if st.button("Guardar este organigrama", icon=":material/save:"):
                    n = db.reemplazar_organigrama(EMPRESA_ID, personas, "excel/csv")
                    st.success(f"Organigrama guardado ({n} personas).")
                    st.rerun()
        else:
            up = st.file_uploader("Subí una base SQLite (.db)", type=["db", "sqlite", "sqlite3"], key="org_db")
            tabla = st.text_input("Nombre de la tabla con el organigrama", value="empleados")
            if up is not None and tabla.strip():
                import sqlite3 as _sqlite3
                import tempfile as _tmp
                import os as _os
                _p = _os.path.join(_tmp.gettempdir(), "org_upload.db")
                with open(_p, "wb") as _f:
                    _f.write(up.getbuffer())
                try:
                    _conn = _sqlite3.connect(_p)
                    df_org = pd.read_sql_query(f"SELECT * FROM {tabla.strip()}", _conn)
                    _conn.close()
                    personas = organigrama.parsear(df_org)
                    st.write(f"{len(personas)} persona(s) detectada(s):")
                    st.dataframe(pd.DataFrame(personas), use_container_width=True)
                    if st.button("Guardar este organigrama", icon=":material/save:"):
                        n = db.reemplazar_organigrama(EMPRESA_ID, personas, "sqlite")
                        st.success(f"Organigrama guardado ({n} personas).")
                        st.rerun()
                except Exception as e:
                    st.error(f"No pude leer la tabla '{tabla}': {e}")
        st.caption("¿Tenés el organigrama como foto? Se puede, pero extraer texto de una imagen "
                   "necesita un proveedor de IA con visión configurado. Sin eso, exportalo a "
                   "Excel/CSV y subilo acá.")

    if not _org_actual.empty:
        st.subheader("Organigrama actual")
        st.dataframe(_org_actual, use_container_width=True)

        st.divider()
        st.subheader("Responsables por etapa (pre-recomendados por IA)")
        personas = _org_actual.to_dict("records")
        sugerencias = organigrama.sugerir_responsables(personas, _provs[0] if _provs else None)
        for s in sugerencias:
            per = s["persona"]
            _resp = organigrama.responsable_vigente(EMPRESA_ID, s["etapa_clave"])
            with st.expander(s["etapa_nombre"]):
                st.caption(s["etapa_desc"])
                if _resp:
                    st.success(f"Asignado: {seguro.escapar(_resp['persona'].get('nombre'))} "
                               f"({seguro.escapar(_resp['persona'].get('cargo') or 's/d')}) — "
                               f"validado por {seguro.escapar(_resp['validado_por_nombre'])}, "
                               f"{seguro.escapar(_resp['validado_por_cargo'])}")
                if per:
                    st.markdown(f"**Recomendado ({s['recomendado_por']}):** "
                                f"{seguro.escapar(per['nombre'])} — "
                                f"{seguro.escapar(per.get('cargo') or 's/d')}")
                    if s["justificacion"]:
                        st.caption(s["justificacion"])
                else:
                    st.warning("El organigrama no tiene un cargo que encaje — asignalo a mano.")
                with st.form(f"resp_{s['etapa_clave']}"):
                    nombres = [p["nombre"] for p in personas]
                    idx = nombres.index(per["nombre"]) if per and per["nombre"] in nombres else 0
                    elegido = st.selectbox("Responsable", nombres, index=idx, key=f"resp_sel_{s['etapa_clave']}")
                    cargo_p = next((p.get("cargo") for p in personas if p["nombre"] == elegido), None)
                    cv1, cv2 = st.columns(2)
                    val_n = cv1.text_input("Validado por (nombre)", key=f"resp_vn_{s['etapa_clave']}")
                    val_c = cv2.text_input("Cargo de quien valida", key=f"resp_vc_{s['etapa_clave']}")
                    if st.form_submit_button("Validar responsable", icon=":material/save:") and val_n.strip():
                        organigrama.guardar_responsable(
                            EMPRESA_ID, s["etapa_clave"], elegido, cargo_p or "",
                            s["recomendado_por"], val_n.strip(), val_c.strip())
                        st.success("Responsable validado y guardado.")
                        st.rerun()

elif section == T("nav_import"):
    st.subheader(T("nav_import"))
    st.caption("Subí tu archivo tal como lo tenés. El sistema reconoce solo cómo se "
               "llaman tus columnas y traduce los valores — no hace falta que lo "
               "prepares antes.")

    # El resultado se guarda en sesión porque después de importar hay un rerun:
    # sin esto el st.success() se pierde y la pantalla queda mostrando "no queda
    # ninguna fila", que parece un error cuando en realidad salió todo bien.
    if st.session_state.get("import_resultado"):
        st.success(st.session_state.pop("import_resultado"))

    tipo_label = st.radio("¿Qué estás importando?", ["Proyectos", "Tareas"], horizontal=True)
    tipo = "proyectos" if tipo_label == "Proyectos" else "tareas"

    with st.expander("¿No sabés cómo armar el archivo? Descargá la plantilla"):
        plantilla_df = importer.plantilla(tipo)
        st.dataframe(plantilla_df, use_container_width=True)
        st.download_button(
            f"Plantilla de {tipo_label.lower()} (CSV)",
            plantilla_df.to_csv(index=False).encode("utf-8-sig"),
            file_name=f"plantilla_{tipo}.csv", mime="text/csv",
            icon=":material/download:")
        st.caption("La plantilla es una ayuda, no un requisito: el importador acepta "
                   "cualquier nombre de columna.")

    uploaded = st.file_uploader("Subí un CSV/Excel", type=["csv", "xlsx"])

    if uploaded is not None:
        try:
            # dtype=str a propósito: si se deja que pandas adivine el tipo,
            # convierte "320.000" (trescientos veinte mil, formato de acá) en el
            # float 320.0 ANTES de que lo vea parsear_numero() — y el
            # presupuesto entra mil veces más chico, en silencio, con lo cual
            # "sobre_presupuesto" queda mal. Leyendo todo como texto, el que
            # decide es el parser del importador, que para eso distingue
            # separador de miles de separador decimal y avisa cuando es ambiguo.
            df_import = (pd.read_csv(uploaded, dtype=str)
                         if uploaded.name.lower().endswith("csv")
                         else pd.read_excel(uploaded, dtype=str))
        except Exception as exc:                                  # archivo ilegible
            st.error(f"No pude leer el archivo: {exc}")
            df_import = None

        if df_import is not None and df_import.empty:
            st.warning("El archivo no tiene filas.")
            df_import = None

        if df_import is not None:
            df_import.columns = [str(c) for c in df_import.columns]
            st.write(f"**{len(df_import)} filas, {len(df_import.columns)} columnas.**")
            st.dataframe(df_import.head(10), use_container_width=True)

            # --- paso 1: mapeo de columnas -------------------------------------
            st.markdown("#### 1. Revisá a qué corresponde cada columna")
            sugerencias = importer.detectar_columnas(df_import, tipo)
            opciones = ["— sin usar —"] + list(df_import.columns)
            mapeo: dict[str, str] = {}

            for campo in importer.campos_de(tipo):
                sug = sugerencias[campo.clave]
                col1, col2 = st.columns([3, 2])
                etiqueta = campo.etiqueta + (" *" if campo.requerido else "")
                indice = opciones.index(sug.columna) if sug.columna in opciones else 0
                elegida = col1.selectbox(etiqueta, opciones, index=indice,
                                         key=f"map_{tipo}_{campo.clave}",
                                         help=campo.ayuda or None)
                if sug.columna:
                    icono = "✅" if sug.confianza >= 0.9 else "🟡"
                    col2.caption(f"{icono} detectado: {sug.motivo}")
                elif campo.requerido:
                    col2.caption("hace falta elegir una columna")
                else:
                    col2.caption("—")
                if elegida != "— sin usar —":
                    mapeo[campo.clave] = elegida

            # --- paso 2: opciones ----------------------------------------------
            st.markdown("#### 2. Opciones")
            omitir_dup = st.checkbox(
                "Omitir filas repetidas y las que ya existen en el sistema", value=True)

            proyecto_default_id = None
            if tipo == "tareas":
                if proj_df.empty:
                    st.error("Todavía no hay proyectos cargados. Importá primero los "
                             "proyectos para poder asociarles las tareas.")
                else:
                    nombres = list(proj_df["nombre"])
                    usar_default = st.checkbox(
                        "Si una tarea no coincide con ningún proyecto, mandarla igual a uno",
                        value="proyecto" not in mapeo)
                    if usar_default:
                        elegido = st.selectbox("Proyecto por defecto", nombres)
                        proyecto_default_id = int(
                            proj_df[proj_df["nombre"] == elegido].iloc[0]["_id"])

            # --- paso 3: informe previo ----------------------------------------
            st.markdown("#### 3. Qué va a pasar")
            # Para el invitado, "lo que ya existe" es lo que subió en esta misma
            # sesión: no se puede consultar la base porque sus datos no están
            # ahí (y los del servidor no son suyos).
            _existentes = (
                (proj_df if tipo == "proyectos" else task_df) if INVITADO else
                (db.projects(incluir_archivados=True) if tipo == "proyectos"
                 else db.tasks()))
            reporte = importer.validar(
                df_import, tipo, mapeo,
                proyectos=proj_df if tipo == "tareas" else None,
                usuarios=(None if INVITADO else
                          (db.listar_usuarios() if tipo == "tareas" else None)),
                existentes=_existentes,
                proyecto_default_id=proyecto_default_id,
                omitir_duplicados=omitir_dup)

            if reporte.faltan_requeridos:
                st.error(reporte.resumen())
            else:
                m1, m2, m3 = st.columns(3)
                m1.metric("Se van a crear", reporte.filas_validas)
                m2.metric("Se descartan", reporte.filas_rechazadas)
                m3.metric("Repetidas", reporte.duplicados_archivo + reporte.duplicados_base)
                st.caption(reporte.resumen())

                for aviso in reporte.avisos_columna:
                    st.warning(aviso)

                if reporte.problemas:
                    with st.expander(f"Ver detalle de {len(reporte.problemas)} observación(es)"):
                        st.dataframe(reporte.problemas_df(), use_container_width=True)
                        st.caption("Severidad «error» descarta la fila; «aviso» la importa "
                                   "igual, dejando ese dato vacío o con el valor por defecto.")

                if reporte.filas:
                    st.write("Vista previa de lo que se va a guardar:")
                    st.dataframe(reporte.vista_previa(), use_container_width=True)

                # --- paso 4: confirmar -----------------------------------------
                st.markdown("#### 4. Confirmar")
                if not reporte.puede_importar:
                    st.info("No queda ninguna fila para importar con estas opciones.")
                elif st.button(f"Importar {reporte.filas_validas} {tipo}", icon=":material/check:",
                               type="primary"):
                    # El importador recibe las funciones de escritura, así que
                    # el invitado usa las de su almacén de sesión y el usuario
                    # registrado las de la base — sin ramificar el importador.
                    _almacen = st.session_state.get("invitado_almacen")
                    _crear_p = _almacen.crear_proyecto if INVITADO else db.crear_proyecto
                    _crear_t = _almacen.crear_tarea if INVITADO else db.crear_tarea
                    creadas = importer.aplicar(reporte, _crear_p, _crear_t)
                    st.session_state["import_resultado"] = (
                        f"Listo: se importaron {creadas} {tipo}. Ya podés verlos en "
                        f"{'Portafolio' if tipo == 'proyectos' else 'Tareas'}.")
                    st.rerun()

elif section == T("nav_plantillas"):
    st.subheader(T("nav_plantillas"))
    st.caption("Gobernanza lista para el rubro del cliente: etapas con puerta de "
               "salida, quién aprueba cada una, riesgos típicos y normativa. Es un "
               "punto de partida para discutir, no una norma.")

    _activa = plantillas.aplicada(EMPRESA_ID)
    if _activa and _activa["plantilla"]:
        _v = _activa["version"]
        _firma = (f" · validada por {_v['validado_por_nombre']}"
                  if _v.get("validado_por_nombre") else " · en borrador")
        st.success(f"Esta empresa adoptó **{_activa['plantilla'].rubro}**{_firma}.")

    _rubros = plantillas.rubros()
    _indice = 0
    if _activa:
        _claves = [c for c, _ in _rubros]
        _indice = _claves.index(_activa["clave"]) if _activa["clave"] in _claves else 0
    _elegido = st.selectbox("Rubro", _rubros, index=_indice,
                            format_func=lambda r: r[1])[0]
    _p = plantillas.obtener(_elegido)
    st.write(f"**{_p.rubro}** — {_p.resumen}")
    if _p.nota:
        st.info(_p.nota)

    _t1, _t2, _t3, _t4 = st.tabs(["Etapas", "Roles y riesgos", "Indicadores y normativa",
                                  "Adoptar"])
    with _t1:
        for _i, _e in enumerate(_p.etapas, 1):
            with st.expander(f"{_i}. {_e.nombre}  ·  {_e.grupo_pmbok}"):
                st.write(f"*{_e.objetivo}*")
                st.write("**Entregables:**")
                for _x in _e.entregables:
                    st.write(f"- {_x}")
                st.write(f"**Puerta de salida:** {_e.criterio_salida}")
                st.write(f"**Aprueba:** {_e.aprueba}")
        st.download_button("Descargar la gobernanza completa (Markdown)",
                           plantillas.como_texto(_elegido).encode("utf-8"),
                           file_name=f"gobernanza_{_elegido}.md", mime="text/markdown",
                           icon=":material/download:")
    with _t2:
        st.write("**Roles y qué decide cada uno**")
        st.dataframe(pd.DataFrame(_p.roles, columns=["Rol", "Qué decide"]),
                     use_container_width=True, hide_index=True)
        st.write("**Riesgos típicos del rubro**")
        st.dataframe(pd.DataFrame([{"Riesgo": _r.titulo, "Área PMBOK": _r.area_pmbok,
                                    "Señal temprana": _r.senal_temprana,
                                    "Mitigación": _r.mitigacion} for _r in _p.riesgos]),
                     use_container_width=True, hide_index=True)
        st.write("**Áreas de PMBOK donde poner el esfuerzo en este rubro**")
        for _a in plantillas.areas_criticas_explicadas(_elegido):
            st.write(f"- **{_a['area']}** — {_a['criollo']}")
        st.caption("Que estas áreas pesen más no significa ignorar las otras: las "
                   "diez aplican siempre.")
    with _t3:
        st.write("**Indicadores que en este rubro se miran de verdad**")
        for _x in _p.indicadores:
            st.write(f"- {_x}")
        st.write("**Normativa de referencia**")
        for _x in _p.normativa:
            st.write(f"- {_x}")
        st.warning("Las referencias normativas son orientativas y están tomadas de "
                   "Uruguay salvo que digan otra cosa. Confirmalas con quien lleva "
                   "calidad, legales o compliance en la empresa: cambian, y cada "
                   "empresa tiene su interpretación. Esto no es asesoramiento legal.")
    with _t4:
        st.write("Adoptar la plantilla la deja registrada como la gobernanza de esta "
                 "empresa, con quién la validó. Queda versionada: cambiarla más "
                 "adelante no borra la historia.")
        with st.form("adoptar_plantilla"):
            _vn = st.text_input("Validada por (nombre)")
            _vc = st.text_input("Cargo de quien valida")
            if st.form_submit_button(f"Adoptar «{_p.rubro}»"):
                plantillas.adoptar(EMPRESA_ID, _elegido, _vn.strip(), _vc.strip())
                st.success("Plantilla adoptada y registrada.")
                st.rerun()
        st.caption("Se puede adoptar sin validar: queda en borrador hasta que "
                   "alguien de la empresa la firme.")

elif section == T("nav_conectores"):
    st.subheader(T("nav_conectores"))
    st.caption("Traer proyectos y tareas directo del ERP. Siempre de solo lectura: "
               "el sistema rechaza cualquier consulta que no sea un SELECT.")

    _fam = conectores.familias()
    _cf1, _cf2 = st.columns([1, 2])
    _familia = _cf1.selectbox("Familia", list(_fam))
    _perfil = _cf2.selectbox("Sistema", _fam[_familia], format_func=lambda p: p.nombre)

    st.write(f"**Cómo se conecta:** {_perfil.como_conectar}")
    for _a in _perfil.advertencias:
        st.warning(_a)

    if not _perfil.consultas:
        st.info("Este perfil no trae consultas de fábrica: escribí la tuya y el "
                "resultado entra por el mismo informe previo que un archivo.")
    else:
        _tipo = st.radio("¿Qué querés traer?", list(_perfil.consultas),
                         horizontal=True, format_func=str.capitalize)
        _ce1, _ce2 = st.columns(2)
        _esquema = _ce1.text_input("Esquema", value=_perfil.esquema_default,
                                   help="Cambia según la instalación. Si el sondeo "
                                        "no encuentra las tablas, suele ser esto.")
        _empresa_erp = _ce2.text_input(
            "Empresa (sólo NAV/Business Central)", value="",
            help="En NAV las tablas llevan la empresa adelante: «CRONUS$Job».")

        _sql = conectores.sql_de(_perfil.clave, _tipo, esquema=_esquema,
                                 empresa=_empresa_erp or "EMPRESA")
        st.write("**Consulta que se va a ejecutar** — editable si tu instalación "
                 "tiene otros nombres:")
        _sql_editado = st.text_area("SQL", value=_sql, height=220,
                                    label_visibility="collapsed")

        _consulta = _perfil.consultas[_tipo]
        if _consulta.nota:
            st.caption(_consulta.nota)
        st.write("**Cómo se interpreta cada columna:**")
        st.dataframe(pd.DataFrame([
            {"Columna": _c.columna, "Va a": _c.destino,
             "Conversión": _c.transformacion, "Nota": _c.nota}
            for _c in _consulta.campos]), use_container_width=True, hide_index=True)

        st.markdown("#### Conectarse")
        _cadena = st.text_input(
            "Cadena de conexión", type="password", placeholder="mssql+pyodbc://...",
            help="Usá un usuario de solo lectura. Es la protección de verdad: el "
                 "candado del software es sólo la segunda línea.")

        _cb1, _cb2 = st.columns(2)
        if _cb1.button("Sondear el esquema", disabled=not _cadena, icon=":material/search:"):
            try:
                _ej = conectores.crear_ejecutor(_cadena)
                _s = conectores.sondear(_ej, _perfil.clave, _tipo, esquema=_esquema,
                                        empresa=_empresa_erp)
                (st.success if _s.sirve else st.error)(_s.resumen())
                if _s.detalle:
                    with st.expander("Detalle del error del motor"):
                        st.json(_s.detalle)
            except Exception as _exc:
                st.error(f"No se pudo conectar: {_exc}")

        if _cb2.button("Traer los datos", disabled=not _cadena, type="primary", icon=":material/download:"):
            try:
                _ej = conectores.crear_ejecutor(_cadena)
                conectores.validar_solo_lectura(_sql_editado)
                _crudo = _ej(_sql_editado)
                _df_erp = conectores.convertir(_crudo, _perfil.clave, _tipo)
                st.session_state["erp_df"] = _df_erp
                st.success(f"Se trajeron {len(_df_erp)} fila(s) del ERP.")
            except conectores.ConsultaInsegura as _exc:
                st.error(str(_exc))
            except Exception as _exc:
                st.error(f"Falló la consulta: {_exc}")

        _df_erp = st.session_state.get("erp_df")
        if _df_erp is not None and not _df_erp.empty:
            st.write("**Lo que llegó del ERP, ya convertido:**")
            st.dataframe(_df_erp.head(20), use_container_width=True)
            st.caption("Revisá un par de fechas e importes contra el ERP antes de "
                       "importar. Es el control que evita una carga silenciosamente "
                       "equivocada.")
            _destino = "proyectos" if _tipo == "proyectos" else "tareas"
            _sug = importer.detectar_columnas(_df_erp, _destino)
            _rep_erp = importer.validar(
                _df_erp, _destino, {k: v.columna for k, v in _sug.items() if v.columna},
                proyectos=proj_df if _destino == "tareas" else None,
                usuarios=db.listar_usuarios() if _destino == "tareas" else None,
                existentes=(db.projects(incluir_archivados=True)
                            if _destino == "proyectos" else db.tasks()),
                proyecto_default_id=(int(proj_df.iloc[0]["_id"])
                                     if _destino == "tareas" and not proj_df.empty
                                     else None))
            _m1, _m2, _m3 = st.columns(3)
            _m1.metric("Se van a crear", _rep_erp.filas_validas)
            _m2.metric("Se descartan", _rep_erp.filas_rechazadas)
            _m3.metric("Repetidas", _rep_erp.duplicados_archivo + _rep_erp.duplicados_base)
            st.caption(_rep_erp.resumen())
            for _av in _rep_erp.avisos_columna:
                st.warning(_av)
            if _rep_erp.problemas:
                with st.expander(f"Ver {len(_rep_erp.problemas)} observación(es)"):
                    st.dataframe(_rep_erp.problemas_df(), use_container_width=True)
            if _rep_erp.puede_importar and st.button(
                    f"Importar {_rep_erp.filas_validas} {_destino}", type="primary", icon=":material/check:",
                    key="importar_erp"):
                _n = importer.aplicar(_rep_erp, db.crear_proyecto, db.crear_tarea)
                st.session_state.pop("erp_df", None)
                st.success(f"Listo: se importaron {_n} {_destino} desde el ERP.")
                st.rerun()

elif section == T("nav_data_eng"):
    st.subheader(T("nav_data_eng"))
    if not (_es_owner or licensing.tiene_feature(LICENSE_TOKEN, "reportes_automaticos")):
        st.warning("Tu plan no incluye la ingeniería de datos. El plan "
                   "Professional sí la incluye.", icon=":material/lock:")
        st.stop()
    st.caption("Perfilá cualquier tabla —no sólo proyectos y tareas— antes de importarla "
               "o de conectarla a un ERP: nulos, duplicados, outliers, la clave primaria "
               "candidata y un `CREATE TABLE` de partida. Sin cargo aparte, incluido en "
               "el mismo plan que los reportes automáticos.")

    _origen = st.radio("¿De dónde vienen los datos?",
                       ["Archivo (CSV/Excel)", "Base de datos (SQL)"], horizontal=True)

    _df_de = None
    _nombre_de = "tabla"

    if _origen == "Archivo (CSV/Excel)":
        _subido_de = st.file_uploader("Subí un CSV/Excel — cualquier esquema",
                                      type=["csv", "xlsx"], key="dataeng_uploader")
        if _subido_de is not None:
            try:
                _df_de = (pd.read_csv(_subido_de) if _subido_de.name.lower().endswith("csv")
                          else pd.read_excel(_subido_de))
                _nombre_de = re.sub(r"\.\w+$", "", _subido_de.name)
            except Exception as _exc:                                # archivo ilegible
                st.error(f"No pude leer el archivo: {_exc}")
    else:
        st.caption("Sólo lectura: la consulta tiene que empezar con SELECT. La cadena "
                   "de conexión no se guarda en ningún lado — vive únicamente en esta sesión.")
        _cadena_de = st.text_input(
            "Cadena de conexión", type="password", placeholder="postgresql://usuario:clave@host/base",
            key="dataeng_cadena",
            help="Usá un usuario de solo lectura. Es la protección de verdad: el "
                 "candado del software es sólo la segunda línea.")
        _consulta_de = st.text_area(
            "Consulta SELECT", placeholder="SELECT * FROM mi_tabla", key="dataeng_consulta")
        _nombre_de = st.text_input("Nombre para el reporte", value="consulta_sql",
                                   key="dataeng_nombre")
        if st.button("Perfilar", disabled=not (_cadena_de and _consulta_de),
                     type="primary", icon=":material/search:"):
            try:
                st.session_state["dataeng_reporte"] = dataeng.perfilar_consulta_sql(
                    _cadena_de, _consulta_de, nombre=_nombre_de or "consulta_sql")
            except conectores.ConsultaInsegura as _exc:
                st.error(str(_exc))
            except RuntimeError as _exc:                    # falta SQLAlchemy/driver
                st.error(str(_exc))
            except Exception as _exc:
                st.error(f"Falló la consulta: {_exc}")

    if _df_de is not None:
        if _df_de.empty:
            st.warning("El archivo no tiene filas.")
        else:
            st.session_state["dataeng_reporte"] = dataeng.perfilar_tabla(_nombre_de, _df_de)

    _reporte_de = st.session_state.get("dataeng_reporte")
    if _reporte_de is not None:
        st.markdown(f"### Resultado — {_reporte_de.nombre}")
        _p = _reporte_de.perfil
        _c = _reporte_de.calidad
        _m1, _m2, _m3, _m4 = st.columns(4)
        _m1.metric("Filas", _p["filas"])
        _m2.metric("Columnas", _p["columnas"])
        _m3.metric("Score de calidad", f"{_c['score']:.0f} / 100")
        _m4.metric("Problemas detectados", len(_c["issues"]))

        if _reporte_de.cambios_tipado:
            with st.expander(f"Tipos corregidos antes de perfilar ({len(_reporte_de.cambios_tipado)})"):
                st.dataframe(pd.DataFrame(_reporte_de.cambios_tipado,
                                          columns=["Columna", "Tipo antes", "Tipo después"]),
                            use_container_width=True, hide_index=True)

        st.markdown("#### Perfil por columna")
        st.dataframe(pd.DataFrame(_p["detalle"]), use_container_width=True, hide_index=True)

        st.markdown("#### Problemas de calidad")
        if _c["issues"]:
            st.dataframe(pd.DataFrame(_c["issues"]), use_container_width=True, hide_index=True)
        else:
            st.success("No se detectaron problemas de calidad.")

        if _reporte_de.claves["pk"]:
            st.markdown("#### Clave primaria candidata")
            st.dataframe(pd.DataFrame(_reporte_de.claves["pk"]),
                        use_container_width=True, hide_index=True)

        if _reporte_de.tiempo:
            st.markdown("#### Cobertura temporal")
            _t = _reporte_de.tiempo
            _t1, _t2, _t3 = st.columns(3)
            _t1.metric("Desde", str(_t["desde"])[:10])
            _t2.metric("Hasta", str(_t["hasta"])[:10])
            _t3.metric("Días sin datos", _t["dias_faltantes"])
            if _t["futuras"]:
                st.warning(f"{_t['futuras']} fecha(s) en el futuro en «{_t['columna']}».")

        st.markdown("#### Descargas")
        _dd1, _dd2 = st.columns(2)
        _dd1.download_button("DDL sugerido (.sql)", _reporte_de.ddl,
                             file_name=f"{_reporte_de.nombre}.sql", icon=":material/download:")
        _dd2.download_button("Informe completo (Excel)",
                             dataeng.exportar_excel_bytes(_reporte_de),
                             file_name=f"perfil_{_reporte_de.nombre}.xlsx",
                             icon=":material/download:")

elif section == T("nav_capacitacion"):
    st.subheader(T("nav_capacitacion"))
    st.caption("Cada rol necesita cosas distintas. Al sponsor no le sirve aprender a "
               "cargar dependencias — y si le hacés mirar una hora de video, no mira "
               "nada. Cada módulo está listo para grabar una vez y reusar.")

    _rol = st.selectbox("Rol", capacitacion.roles(),
                        format_func=lambda r: f"{r[1]} — {r[2]} min")[0]
    _c = capacitacion.obtener(_rol)

    st.write(f"**{_c.rol}** · {_c.minutos} minutos en {len(_c.modulos)} módulos")
    st.write(f"**Para quién:** {_c.para_quien}")
    st.write(f"**Al terminar va a poder:** {_c.promesa}")
    if _c.requiere:
        st.info("Antes de esto: " +
                ", ".join(capacitacion.obtener(_r).rol for _r in _c.requiere))

    _tc1, _tc2, _tc3 = st.tabs(["Módulos", "Verificación", "Plan de grabación"])
    with _tc1:
        for _i, _m in enumerate(_c.modulos, 1):
            with st.expander(f"{_i}. {_m.titulo}  ·  {_m.minutos} min"):
                st.write(f"*{_m.objetivo}* — se hace en «{_m.seccion_app}».")
                st.write("**Guion:**")
                for _j, _paso in enumerate(_m.guion, 1):
                    st.write(f"{_j}. {_paso}")
                st.write(f"**Práctica:** {_m.practica}")
                st.write("**Verificación:**")
                for _v in _m.verificacion:
                    st.write(f"- {_v}")
        st.download_button("Descargar el guion completo (Markdown)",
                           capacitacion.guion_de(_rol).encode("utf-8"),
                           file_name=f"capacitacion_{_rol}.md", mime="text/markdown",
                           icon=":material/download:")
    with _tc2:
        st.write("Preguntas de toda la ruta, incluidos los requisitos previos. Si la "
                 "persona las contesta, puede trabajar sola.")
        st.dataframe(pd.DataFrame(capacitacion.checklist_de_verificacion(_rol)),
                     use_container_width=True, hide_index=True)
    with _tc3:
        _plan = capacitacion.plan_de_grabacion()
        st.write(f"**{len(_plan)} módulos, {capacitacion.minutos_totales_a_grabar()} "
                 f"minutos** para cubrir los seis roles. Un módulo que usan varios "
                 f"roles se graba una sola vez.")
        st.dataframe(pd.DataFrame([
            {"Módulo": _m["titulo"], "Min": _m["minutos"],
             "Dónde": _m["seccion_app"], "Roles": ", ".join(_m["roles"])}
            for _m in _plan]), use_container_width=True, hide_index=True)

elif section == T("nav_config_ia"):
    st.subheader(T("cfg_titulo"))
    st.caption(T("cfg_intro"))

    _provs_cfg = modelos.con_clave()
    if not _provs_cfg:
        st.info(T("cfg_sin_proveedores"))
        st.code("\n".join(
            f"export {_cfg['env_clave']}=...    # {_cfg['etiqueta']}"
            for _cfg in modelos.PROVEEDORES.values()), language="bash")
    else:
        # El catálogo traído de la API vive en la sesión, no en la base: es una
        # foto de lo que el proveedor contestó hoy y mañana puede ser otra. Lo
        # que sí se persiste —porque es una decisión del cliente— es el modelo
        # elegido.
        _catalogos = st.session_state.setdefault("catalogos_ia", {})

        for _prov_cfg in _provs_cfg:
            with st.expander(modelos.etiqueta(_prov_cfg), expanded=True, icon=":material/smart_toy:"):
                _elegido_actual = modelos.modelo_actual(_prov_cfg)
                st.caption(f"{T('cfg_en_uso')}: "
                           f"**{_elegido_actual or T('cfg_sin_elegir')}**")

                if st.button(T("cfg_actualizar"), key=f"cfg_upd_{_prov_cfg}",
                             icon=":material/refresh:",
                             help=T("cfg_actualizar_ayuda")):
                    try:
                        _catalogos[_prov_cfg] = modelos.listar_desde_api(_prov_cfg)
                        st.success(f"{len(_catalogos[_prov_cfg])} {T('cfg_traidos')}.")
                    except modelos.ErrorDeProveedor as exc:
                        # Se muestra el motivo: el usuario apretó un botón que
                        # dice "actualizar" y merece saber por qué no pasó nada.
                        st.error(seguro.escapar(str(exc)))

                _lista = _catalogos.get(_prov_cfg, [])
                if not _lista:
                    st.caption(T("cfg_sin_catalogo"))

                with st.form(f"cfg_form_{_prov_cfg}"):
                    _opciones = [T("cfg_sin_elegir"), *_lista]
                    _idx = (_opciones.index(_elegido_actual)
                            if _elegido_actual in _opciones else 0)
                    _sel = st.selectbox(T("cfg_modelo"), _opciones, index=_idx,
                                        key=f"cfg_sel_{_prov_cfg}")
                    # Escape para el proveedor sin endpoint de listado, o
                    # cuando el catálogo falla y el cliente igual sabe qué ID
                    # quiere usar. Lo escrito a mano le gana a lo elegido.
                    _manual = st.text_input(T("cfg_modelo_manual"),
                                            key=f"cfg_man_{_prov_cfg}")
                    if st.form_submit_button(T("cfg_guardar"), icon=":material/save:"):
                        _nuevo = _manual.strip() or (
                            _sel if _sel != T("cfg_sin_elegir") else None)
                        modelos.fijar_modelo(_prov_cfg, _nuevo)
                        db.guardar_version(EMPRESA_ID, "config_ia", "modelos",
                                           modelos.serializar_seleccion(),
                                           estado="vigente",
                                           recomendado_por=user["nombre"])
                        st.success(T("cfg_guardado"))
                        st.rerun()

        _hist_ia = db.historial_versiones(EMPRESA_ID, "config_ia", "modelos")
        if len(_hist_ia) > 0:
            with st.expander(f"{T('cfg_historial')} ({len(_hist_ia)})", icon=":material/history_edu:"):
                st.dataframe(_hist_ia[["contenido", "recomendado_por", "creado_en"]],
                             use_container_width=True, hide_index=True)

elif section == T("nav_users"):
    st.subheader(T("nav_users"))
    st.dataframe(equipo_df, use_container_width=True)
    st.caption("Para sumar gente al equipo, pedile que se registre desde la pantalla de login de este mismo servidor con 'Crear cuenta'.")
